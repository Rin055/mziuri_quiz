from django.apps import AppConfig


class OrdersConfig(AppConfig):
    name = 'project.orders'
